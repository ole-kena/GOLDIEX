package com.goldie.tools

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.graphics.Color
import android.view.View
import androidx.core.app.NotificationManagerCompat
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ActivityCompat
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.JavascriptInterface
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.webkit.PermissionRequest
import java.util.Locale
import android.Manifest
import android.content.Context

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        createNotificationChannels()
        requestNotificationPermission()
        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(7, 7, 7))
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.settings.setSupportZoom(false)
        webView.settings.builtInZoomControls = false
        webView.settings.displayZoomControls = false
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                return if (uri.scheme == "http" || uri.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri)); true
                } else false
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(GoldieBridge(), "GoldieNative")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = (tts?.setLanguage(Locale.US) ?: TextToSpeech.LANG_MISSING_DATA) >= TextToSpeech.LANG_AVAILABLE
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val trade = NotificationChannel("goldie_trade", "Trade announcements", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "GOLDIE XAUUSD trade event notifications"
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
            }
            val kz = NotificationChannel("goldie_killzone_v2", "Killzone alarm alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Loud alarm sound and vibration for GOLDIE Killzone open and close alerts"
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 800)
            }
            manager.createNotificationChannel(trade)
            manager.createNotificationChannel(kz)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 410)
        }
    }

    private fun postGoldieNotification(title: String, body: String, channel: String) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title.take(80)).setContentText(body.take(180))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    inner class GoldieBridge {
        @JavascriptInterface fun speak(message: String) {
            runOnUiThread { if (ttsReady) tts?.speak(message.take(240), TextToSpeech.QUEUE_FLUSH, null, "goldie-trade-voice") }
        }
        @JavascriptInterface fun tradeNotification(message: String) {
            runOnUiThread { postGoldieNotification("GOLDIE TRADE", message, "goldie_trade") }
        }
        @JavascriptInterface fun killzoneAlert(message: String) {
            runOnUiThread { postGoldieNotification("GOLDIE KILLZONE", message, "goldie_killzone_v2") }
        }
        @JavascriptInterface fun notificationsEnabled(): Boolean {
            val permissionGranted = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            return permissionGranted && NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled()
        }
        @JavascriptInterface fun requestNotifications() {
            runOnUiThread { requestNotificationPermission() }
        }
        @JavascriptInterface fun platform(): String = "android"
        @JavascriptInterface fun appVersion(): String = "3.0.0-dev06"
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) { webView.stopLoading(); webView.destroy() }
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
}
