"""GOLDIE V3 minimal MT5 event receiver. Read-only journal ingestion."""
import os, sqlite3
from contextlib import closing
from datetime import datetime, timezone
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

DB_PATH=os.getenv('GOLDIE_DB_PATH','goldie_journal.sqlite3')
API_KEY=os.getenv('GOLDIE_MT5_API_KEY','')
app=FastAPI(title='GOLDIE V3 Journal Bridge', version='0.1.0')

class TradeEvent(BaseModel):
    event_id: str
    deal_ticket: str
    position_id: str
    symbol: str
    entry: str
    direction: str
    price: float
    volume: float
    profit: float = 0
    commission: float = 0
    swap: float = 0
    deal_time_msc: int
    sl_at_entry: float | None = None
    tp_at_entry: float | None = None
    initial_risk_usd: float | None = None


def connect():
    c=sqlite3.connect(DB_PATH)
    c.row_factory=sqlite3.Row
    return c

@app.on_event('startup')
def startup():
    with closing(connect()) as c:
        c.execute('''CREATE TABLE IF NOT EXISTS mt5_events (
          event_id TEXT PRIMARY KEY, deal_ticket TEXT NOT NULL, position_id TEXT NOT NULL,
          symbol TEXT NOT NULL, entry TEXT NOT NULL, direction TEXT NOT NULL,
          price REAL NOT NULL, volume REAL NOT NULL, profit REAL NOT NULL,
          commission REAL NOT NULL, swap REAL NOT NULL, deal_time_msc INTEGER NOT NULL,
          sl_at_entry REAL, tp_at_entry REAL, initial_risk_usd REAL, received_at TEXT NOT NULL
        )''')
        c.commit()

@app.get('/health')
def health():
    return {'service':'GOLDIE V3 journal bridge','status':'ok'}

@app.post('/mt5/event')
def receive_event(event: TradeEvent, x_goldie_key: str = Header(default='')):
    if not API_KEY or x_goldie_key != API_KEY:
        raise HTTPException(status_code=401, detail='Invalid API key')
    if not event.symbol.startswith('XAUUSD'):
        raise HTTPException(status_code=422, detail='Only XAUUSD symbols are accepted')
    with closing(connect()) as c:
        cur=c.execute('''INSERT OR IGNORE INTO mt5_events VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
          (event.event_id,event.deal_ticket,event.position_id,event.symbol,event.entry,event.direction,
           event.price,event.volume,event.profit,event.commission,event.swap,event.deal_time_msc,
           event.sl_at_entry,event.tp_at_entry,event.initial_risk_usd,datetime.now(timezone.utc).isoformat()))
        c.commit()
        return {'accepted':True,'duplicate':cur.rowcount==0,'deal_ticket':event.deal_ticket}

def classify_window(ts_msc: int):
    """Classify an event using New York wall time (DST-aware) and return Addis display time."""
    from zoneinfo import ZoneInfo
    dt=datetime.fromtimestamp(ts_msc/1000, timezone.utc)
    ny=dt.astimezone(ZoneInfo('America/New_York'))
    addis=dt.astimezone(ZoneInfo('Africa/Addis_Ababa'))
    minute=ny.hour*60+ny.minute
    windows=[('Asian Killzone',19*60,22*60),('London Open',2*60,5*60),
             ('New York AM',7*60,10*60),('London Close',10*60,12*60),('New York PM',13*60,16*60)]
    sessions=[('Asian Session',18*60,24*60),('London Session',60,12*60),
              ('New York AM Session',8*60,12*60),('New York PM Session',13*60,16*60+30)]
    def match(items):
        for name,a,b in items:
            if a <= minute < b: return name
        return 'Outside'
    return {'killzone':match(windows),'session':match(sessions),
            'addis_time':addis.isoformat(timespec='seconds')}

@app.get('/api/journal')
def journal():
    """Aggregate MT5 deal events by position identifier; R is omitted when initial risk is unknown."""
    with closing(connect()) as c:
        rows=c.execute('SELECT * FROM mt5_events WHERE symbol LIKE "XAUUSD%" ORDER BY deal_time_msc ASC').fetchall()
    grouped={}
    for row in rows:
        e=dict(row); key=e['position_id']
        t=grouped.setdefault(key, {'position_id':key,'symbol':e['symbol'],'direction':e['direction'],
            'events':[],'net_pnl':0.0,'volume_in':0.0,'volume_out':0.0,'initial_risk_usd':None,
            'entry_time_msc':None,'close_time_msc':None,'status':'OPEN','entry_price':None,
            'entry_sl':None,'entry_tp':None})
        t['events'].append(e)
        t['net_pnl'] += float(e['profit'])+float(e['commission'])+float(e['swap'])
        if e['entry']=='IN':
            t['volume_in'] += float(e['volume'])
            if t['entry_time_msc'] is None:
                t['entry_time_msc']=e['deal_time_msc']; t['entry_price']=e['price']
                t['entry_sl']=e['sl_at_entry']; t['entry_tp']=e['tp_at_entry']
                t['initial_risk_usd']=e['initial_risk_usd']
        elif e['entry'] in ('OUT','OUT_BY','INOUT'):
            t['volume_out'] += float(e['volume']); t['close_time_msc']=e['deal_time_msc']
    trades=[]
    for t in grouped.values():
        t['net_pnl']=round(t['net_pnl'],2)
        if t['close_time_msc'] is not None and t['volume_out'] >= t['volume_in']-1e-8: t['status']='CLOSED'
        t['r_multiple']=round(t['net_pnl']/t['initial_risk_usd'],2) if t['initial_risk_usd'] and t['initial_risk_usd']>0 and t['status']=='CLOSED' else None
        stamp=t['entry_time_msc'] or (t['events'][0]['deal_time_msc'] if t['events'] else 0)
        t.update(classify_window(stamp) if stamp else {'killzone':'Unknown','session':'Unknown','addis_time':None})
        t['event_count']=len(t['events']); t.pop('events',None)
        trades.append(t)
    trades.sort(key=lambda x:x['entry_time_msc'] or 0,reverse=True)
    closed=[t for t in trades if t['status']=='CLOSED']
    wins=[t for t in closed if t['net_pnl']>0]
    known_r=[t['r_multiple'] for t in closed if t['r_multiple'] is not None]
    return {'trades':trades[:200], 'event_count':len(rows),
            'stats':{'closed_trades':len(closed),'net_pnl':round(sum(t['net_pnl'] for t in closed),2),
                     'win_rate':round(100*len(wins)/len(closed),1) if closed else None,
                     'average_r':round(sum(known_r)/len(known_r),2) if known_r else None,
                     'trades_with_known_r':len(known_r)},
            'note':'R is shown only when original risk was captured at entry. Partial closes are grouped by MT5 position ID.'}
