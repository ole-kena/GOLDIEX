// GOLDIE TOOLS V3 — XAUUSD MT5 event monitor (read-only)
// Attach to an XAUUSD chart. Configure the endpoint and API key supplied by your GOLDIE server.
// This EA sends trade-event data only. It contains no order placement or modification functions.
#property strict
#property version   "1.00"
#property description "GOLDIE XAUUSD-only trade event monitor. Read-only; no trade execution."

input string InpEndpoint = "https://YOUR-GOLDIE-SERVER/mt5/event";
input string InpApiKey = "CHANGE_ME";
input int    InpTimeoutMs = 5000;
input bool   InpAllowSymbolSuffix = true; // accepts XAUUSD.a / XAUUSDm broker suffixes

bool IsGoldSymbol(const string symbol)
{
   if(symbol == "XAUUSD") return true;
   return InpAllowSymbolSuffix && StringFind(symbol, "XAUUSD") == 0;
}

string JsonEscape(const string value)
{
   string out=value;
   StringReplace(out, "\\", "\\\\");
   StringReplace(out, "\"", "\\\"");
   StringReplace(out, "\r", "\\r");
   StringReplace(out, "\n", "\\n");
   return out;
}

string EntryName(const long entry)
{
   if(entry==DEAL_ENTRY_IN) return "IN";
   if(entry==DEAL_ENTRY_OUT) return "OUT";
   if(entry==DEAL_ENTRY_INOUT) return "INOUT";
   if(entry==DEAL_ENTRY_OUT_BY) return "OUT_BY";
   return "OTHER";
}

string DirectionName(const long deal_type)
{
   if(deal_type==DEAL_TYPE_BUY) return "BUY";
   if(deal_type==DEAL_TYPE_SELL) return "SELL";
   return "UNKNOWN";
}

void SendEvent(const ulong deal_ticket)
{
   if(!HistoryDealSelect(deal_ticket)) return;
   string symbol=HistoryDealGetString(deal_ticket, DEAL_SYMBOL);
   if(!IsGoldSymbol(symbol)) return;

   long entry=HistoryDealGetInteger(deal_ticket, DEAL_ENTRY);
   long deal_type=HistoryDealGetInteger(deal_ticket, DEAL_TYPE);
   long position_id=HistoryDealGetInteger(deal_ticket, DEAL_POSITION_ID);
   long time_msc=HistoryDealGetInteger(deal_ticket, DEAL_TIME_MSC);
   double price=HistoryDealGetDouble(deal_ticket, DEAL_PRICE);
   double volume=HistoryDealGetDouble(deal_ticket, DEAL_VOLUME);
   double profit=HistoryDealGetDouble(deal_ticket, DEAL_PROFIT);
   double commission=HistoryDealGetDouble(deal_ticket, DEAL_COMMISSION);
   double swap=HistoryDealGetDouble(deal_ticket, DEAL_SWAP);

   double sl=0.0, tp=0.0, initial_risk=0.0;
   bool has_sl=false, has_tp=false, risk_known=false;
   ulong position_ticket=0;
   if(entry==DEAL_ENTRY_IN || entry==DEAL_ENTRY_INOUT)
   {
      ulong position_identifier=(ulong)HistoryDealGetInteger(deal_ticket, DEAL_POSITION_ID);
      // DEAL_POSITION_ID is the position identifier, not guaranteed to be its ticket.
      for(int i=PositionsTotal()-1; i>=0; --i)
      {
         ulong candidate=PositionGetTicket(i);
         if(candidate==0) continue;
         if(PositionSelectByTicket(candidate) && (ulong)PositionGetInteger(POSITION_IDENTIFIER)==position_identifier)
         { position_ticket=candidate; break; }
      }
      if(position_ticket>0 && PositionSelectByTicket(position_ticket))
      {
         sl=PositionGetDouble(POSITION_SL);
         tp=PositionGetDouble(POSITION_TP);
         has_sl=(sl>0.0); has_tp=(tp>0.0);
         if(has_sl)
         {
            ENUM_POSITION_TYPE pt=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
            ENUM_ORDER_TYPE ot=(pt==POSITION_TYPE_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
            double calculated=0.0;
            if(OrderCalcProfit(ot, symbol, volume, price, sl, calculated))
            {
               initial_risk=MathAbs(calculated);
               risk_known=(initial_risk>0.0);
            }
         }
      }
   }

   string sl_json=has_sl?DoubleToString(sl,_Digits):"null";
   string tp_json=has_tp?DoubleToString(tp,_Digits):"null";
   string risk_json=risk_known?DoubleToString(initial_risk,2):"null";
   string direction=DirectionName(deal_type);
   string body=StringFormat(
      "{\"event_id\":\"%I64u\",\"deal_ticket\":\"%I64u\",\"position_id\":\"%I64d\",\"symbol\":\"%s\",\"entry\":\"%s\",\"direction\":\"%s\",\"price\":%.8f,\"volume\":%.4f,\"profit\":%.2f,\"commission\":%.2f,\"swap\":%.2f,\"deal_time_msc\":%I64d,\"sl_at_entry\":%s,\"tp_at_entry\":%s,\"initial_risk_usd\":%s}",
      deal_ticket,deal_ticket,position_id,JsonEscape(symbol),EntryName(entry),direction,price,volume,profit,commission,swap,time_msc,sl_json,tp_json,risk_json);

   char post[]; StringToCharArray(body,post,0,WHOLE_ARRAY,CP_UTF8);
   if(ArraySize(post)>0) ArrayResize(post,ArraySize(post)-1); // remove terminating zero
   char result[]; string response_headers;
   string headers="Content-Type: application/json\r\nX-GOLDIE-KEY: "+InpApiKey+"\r\n";
   ResetLastError();
   int status=WebRequest("POST",InpEndpoint,headers,InpTimeoutMs,post,result,response_headers);
   if(status<200 || status>=300)
      Print("GOLDIE: event send failed. HTTP=",status," error=",GetLastError()," deal=",deal_ticket);
   else
      Print("GOLDIE: XAUUSD event sent. deal=",deal_ticket," ",EntryName(entry));
}

void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
{
   if(trans.type!=TRADE_TRANSACTION_DEAL_ADD || trans.deal==0) return;
   SendEvent(trans.deal);
}
